# Employee Payroll System (Java)

This project implements the UML class diagram with these types:

- `Employee`: abstract parent class with shared employee details and abstract `calculateSalary()`.
- `Gender`: enum with `MALE` and `FEMALE`.
- `CommissionEmployee`, `MonthlyEmployee`, `HourlyEmployee`: concrete subclasses of `Employee`.
- `Department`: stores a manager and employees, and calculates total payroll.
- `Main`: runnable demonstration.

## Run the project

Requires JDK 8 or later.

### IntelliJ IDEA / Eclipse / NetBeans / VS Code
1. Extract the ZIP.
2. Open `EmployeePayrollProject` as a Java project (or create a project and copy `src` into it).
3. Make sure `src` is marked as a source folder.
4. Run `payroll.Main`.

### Command line
From the `EmployeePayrollProject` directory:

```bash
javac -d out src/payroll/*.java
java -cp out payroll.Main
```

## Calculation assumptions
The UML gives method names but not formulas, so this implementation uses clear example rules:
- Commission salary = base salary + (sales amount × commission rate).
- Monthly salary = monthly salary + (monthly salary × bonus percentage).
- Hourly salary = up to 40 hours at the regular hourly rate, then remaining hours at `overtimeRate`.
- Additional vacation = one extra day per five completed years of service.

Rates are decimals: `0.05` means 5%, and `0.10` means 10%. The overtime rate is treated as the actual pay per overtime hour, not a multiplier.
