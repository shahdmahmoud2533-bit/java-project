package payroll;

import java.time.LocalDate;
import java.time.Period;

/** Employee receiving a fixed monthly salary and benefits. */
public class MonthlyEmployee extends Employee {
    private double monthlySalary;
    private int vacationDays;
    private double bonusPercentage;
    private boolean hasHealthInsurance;

    public MonthlyEmployee(int id, String name, Gender gender, LocalDate hireDate,
                           double monthlySalary, int vacationDays,
                           double bonusPercentage, boolean hasHealthInsurance) {
        super(id, name, gender, hireDate);
        setMonthlySalary(monthlySalary);
        setVacationDays(vacationDays);
        setBonusPercentage(bonusPercentage);
        this.hasHealthInsurance = hasHealthInsurance;
    }

    public double getMonthlySalary() { return monthlySalary; }
    public void setMonthlySalary(double monthlySalary) {
        if (monthlySalary < 0) throw new IllegalArgumentException("monthlySalary cannot be negative");
        this.monthlySalary = monthlySalary;
    }

    public int getVacationDays() { return vacationDays; }
    public void setVacationDays(int vacationDays) {
        if (vacationDays < 0) throw new IllegalArgumentException("vacationDays cannot be negative");
        this.vacationDays = vacationDays;
    }

    /** Bonus percentage is represented as a decimal (e.g. 0.10 means 10%). */
    public double getBonusPercentage() { return bonusPercentage; }
    public void setBonusPercentage(double bonusPercentage) {
        if (bonusPercentage < 0) throw new IllegalArgumentException("bonusPercentage cannot be negative");
        this.bonusPercentage = bonusPercentage;
    }

    public boolean getHasHealthInsurance() { return hasHealthInsurance; }
    public void setHasHealthInsurance(boolean hasHealthInsurance) {
        this.hasHealthInsurance = hasHealthInsurance;
    }

    @Override
    public double calculateSalary() {
        return monthlySalary + monthlySalary * bonusPercentage;
    }

    /** Adds one vacation day for every completed five years of service. */
    public int calculateAdditionalVacation() {
        int yearsOfService = Math.max(0, Period.between(getHireDate(), LocalDate.now()).getYears());
        return yearsOfService / 5;
    }

    @Override
    public String toString() {
        return super.toString() + String.format(
                ", MonthlyEmployee{monthlySalary=%.2f, bonusPercentage=%.2f, vacationDays=%d, additionalVacation=%d, healthInsurance=%s}",
                monthlySalary, bonusPercentage, vacationDays, calculateAdditionalVacation(), hasHealthInsurance);
    }
}
