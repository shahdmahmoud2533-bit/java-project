package payroll;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;

/** A department manages its employees and has one manager. */
public class Department {
    private int id;
    private String name;
    private Employee manager;
    private final List<Employee> employees = new ArrayList<>();

    public Department(int id, String name, Employee manager, List<Employee> employees) {
        this.id = id;
        this.name = Objects.requireNonNull(name, "name cannot be null");
        this.manager = manager;
        if (employees != null) {
            for (Employee employee : employees) addEmployee(employee);
        }
        if (manager != null) addEmployee(manager);
    }

    public Department(int id, String name) {
        this(id, name, null, null);
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getName() { return name; }
    public void setName(String name) {
        this.name = Objects.requireNonNull(name, "name cannot be null");
    }

    public Employee getManager() { return manager; }
    public void setManager(Employee manager) {
        this.manager = manager;
        if (manager != null) addEmployee(manager);
    }

    /** Returns an unmodifiable view to protect the department's employee list. */
    public List<Employee> getEmployees() {
        return Collections.unmodifiableList(employees);
    }

    public void addEmployee(Employee employee) {
        Objects.requireNonNull(employee, "employee cannot be null");
        employee.setDepartment(this);
    }

    public void removeEmployee(int employeeId) {
        Employee target = findEmployee(employeeId);
        if (target != null) {
            if (manager == target) manager = null;
            target.setDepartment(null);
        }
    }

    /** Internal helper used by Employee to keep both sides of the association synchronized. */
    void addEmployeeInternal(Employee employee) {
        if (!employees.contains(employee)) employees.add(employee);
    }

    /** Internal helper used by Employee to keep both sides of the association synchronized. */
    void removeEmployeeInternal(Employee employee) {
        employees.remove(employee);
        if (manager == employee) manager = null;
    }

    public Employee findEmployee(int employeeId) {
        for (Employee employee : employees) {
            if (employee.getId() == employeeId) return employee;
        }
        return null;
    }

    public double calculateTotalPayroll() {
        double total = 0;
        for (Employee employee : employees) total += employee.calculateSalary();
        return total;
    }

    public void printAllEmployees() {
        if (employees.isEmpty()) {
            System.out.println("No employees in " + name + ".");
            return;
        }
        for (Employee employee : employees) {
            System.out.printf("%s | Salary: %.2f%n", employee, employee.calculateSalary());
        }
    }

    @Override
    public String toString() {
        return String.format("Department{id=%d, name='%s', manager=%s, employeeCount=%d}",
                id, name, manager == null ? "None" : manager.getName(), employees.size());
    }
}
