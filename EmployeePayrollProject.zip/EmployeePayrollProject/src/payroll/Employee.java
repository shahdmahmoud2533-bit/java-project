package payroll;

import java.time.LocalDate;
import java.util.Objects;

/** Common base class for all employee types. */
public abstract class Employee {
    private int id;
    private String name;
    private Gender gender;
    private LocalDate hireDate;
    private Department department;

    public Employee(int id, String name, Gender gender, LocalDate hireDate) {
        this.id = id;
        this.name = Objects.requireNonNull(name, "name cannot be null");
        this.gender = Objects.requireNonNull(gender, "gender cannot be null");
        this.hireDate = Objects.requireNonNull(hireDate, "hireDate cannot be null");
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getName() { return name; }
    public void setName(String name) {
        this.name = Objects.requireNonNull(name, "name cannot be null");
    }

    public Gender getGender() { return gender; }
    public void setGender(Gender gender) {
        this.gender = Objects.requireNonNull(gender, "gender cannot be null");
    }

    public LocalDate getHireDate() { return hireDate; }
    public void setHireDate(LocalDate hireDate) {
        this.hireDate = Objects.requireNonNull(hireDate, "hireDate cannot be null");
    }

    public Department getDepartment() { return department; }

    /** Keeps the employee and department sides of the association synchronized. */
    public void setDepartment(Department department) {
        if (this.department == department) return;
        Department oldDepartment = this.department;
        this.department = null;
        if (oldDepartment != null) oldDepartment.removeEmployeeInternal(this);
        this.department = department;
        if (department != null) department.addEmployeeInternal(this);
    }

    public abstract double calculateSalary();

    @Override
    public String toString() {
        return String.format("Employee{id=%d, name='%s', gender=%s, hireDate=%s, department=%s}",
                id, name, gender, hireDate,
                department == null ? "None" : department.getName());
    }
}
