package payroll;

/** Represents the gender values shown in the UML diagram. */
public enum Gender {
    MALE,
    FEMALE
}
