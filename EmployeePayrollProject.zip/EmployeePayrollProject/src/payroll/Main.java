package payroll;

import java.time.LocalDate;

/** Demonstrates the employee payroll project. */
public class Main {
    public static void main(String[] args) {
        Department engineering = new Department(1, "Engineering");

        MonthlyEmployee manager = new MonthlyEmployee(
                100, "Mona Hassan", Gender.FEMALE, LocalDate.of(2018, 3, 1),
                30000, 25, 0.10, true);

        HourlyEmployee developer = new HourlyEmployee(
                101, "Omar Ali", Gender.MALE, LocalDate.of(2023, 6, 15),
                250, 45, 375);

        CommissionEmployee salesperson = new CommissionEmployee(
                102, "Salma Adel", Gender.FEMALE, LocalDate.of(2022, 1, 10),
                12000, 0.05, 80000);

        engineering.setManager(manager);
        engineering.addEmployee(developer);
        engineering.addEmployee(salesperson);

        System.out.println("=== Department ===");
        System.out.println(engineering);
        System.out.println("\n=== Employees and salaries ===");
        engineering.printAllEmployees();

        System.out.printf("%nTotal monthly payroll: %.2f%n", engineering.calculateTotalPayroll());

        Employee found = engineering.findEmployee(101);
        System.out.println("\nFind employee #101: " + (found == null ? "Not found" : found.getName()));

        engineering.removeEmployee(102);
        System.out.println("After removing employee #102, count = " + engineering.getEmployees().size());
    }
}
